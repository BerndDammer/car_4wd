# Change Log

## [1.2.0] - 2023-1-16

### Added
- Add the method of simplifying the data received by websocket and then sending it to the lower computer through the serial port

### Modified
- Separate code into multiple files for easier reading


## [1.1.0] - 2023-1-11:
- Add version print


## [1.0.3] - 2023-9-30:

### Added
- Add usage of burning esp8266 with pico


## [1.0.2] - 2022-9-9:

### Added
- Add LED to indicate connection


## [1.0.1] - 2021-12-23:

### Modified
- Tide code
- Add timeout for serial read